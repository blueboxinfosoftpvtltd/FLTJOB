import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectaircraftPage } from './selectaircraft';

@NgModule({
  declarations: [
    SelectaircraftPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectaircraftPage),
  ],
})
export class SelectaircraftPageModule {}
