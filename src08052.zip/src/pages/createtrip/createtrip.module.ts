import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreatetripPage } from './createtrip';

@NgModule({
  declarations: [
    CreatetripPage,
  ],
  imports: [
    IonicPageModule.forChild(CreatetripPage),
  ],
})
export class CreatetripPageModule { }
