import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddratingPage } from './addrating';

@NgModule({
  declarations: [
    AddratingPage,
  ],
  imports: [
    IonicPageModule.forChild(AddratingPage),
  ],
})
export class AddratingPageModule {}
