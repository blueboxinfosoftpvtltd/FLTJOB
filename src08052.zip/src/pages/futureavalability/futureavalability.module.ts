import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FutureavalabilityPage } from './futureavalability';

@NgModule({
  declarations: [
    FutureavalabilityPage,
  ],
  imports: [
    IonicPageModule.forChild(FutureavalabilityPage),
  ],
})
export class FutureavalabilityPageModule {}
