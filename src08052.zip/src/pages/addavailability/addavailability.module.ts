import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddavailabilityPage } from './addavailability';

@NgModule({
  declarations: [
    AddavailabilityPage,
  ],
  imports: [
    IonicPageModule.forChild(AddavailabilityPage),
  ],
})
export class AddavailabilityPageModule {}
