import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectcontinentPage } from './selectcontinent';

@NgModule({
  declarations: [
    SelectcontinentPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectcontinentPage),
  ],
})
export class SelectcontinentPageModule {}
