import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectoceansPage } from './selectoceans';

@NgModule({
  declarations: [
    SelectoceansPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectoceansPage),
  ],
})
export class SelectoceansPageModule {}
