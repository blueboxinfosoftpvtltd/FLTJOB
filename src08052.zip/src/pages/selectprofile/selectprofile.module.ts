import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectprofilePage } from './selectprofile';

@NgModule({
  declarations: [
    SelectprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(SelectprofilePage),
  ],
})
export class SelectprofilePageModule {}
