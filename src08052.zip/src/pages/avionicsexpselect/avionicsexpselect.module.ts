import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AvionicsexpselectPage } from './avionicsexpselect';

@NgModule({
  declarations: [
    AvionicsexpselectPage,
  ],
  imports: [
    IonicPageModule.forChild(AvionicsexpselectPage),
  ],
})
export class AvionicsexpselectPageModule {}
