import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddbankdetailPage } from './addbankdetail';

@NgModule({
  declarations: [
    AddbankdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(AddbankdetailPage),
  ],
})
export class AddbankdetailPageModule {}
