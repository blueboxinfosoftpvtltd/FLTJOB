import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DispcurrentratingPage } from './dispcurrentrating';

@NgModule({
  declarations: [
    DispcurrentratingPage,
  ],
  imports: [
    IonicPageModule.forChild(DispcurrentratingPage),
  ],
})
export class DispcurrentratingPageModule {}
