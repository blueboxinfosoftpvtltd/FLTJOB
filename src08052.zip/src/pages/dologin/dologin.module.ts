import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DologinPage } from './dologin';

@NgModule({
  declarations: [
    DologinPage,
  ],
  imports: [
    IonicPageModule.forChild(DologinPage),
  ],
})
export class DologinPageModule {}
