import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OpenpendingnotificationPage } from './openpendingnotification';

@NgModule({
  declarations: [
    OpenpendingnotificationPage,
  ],
  imports: [
    IonicPageModule.forChild(OpenpendingnotificationPage),
  ],
})
export class OpenpendingnotificationPageModule {}
