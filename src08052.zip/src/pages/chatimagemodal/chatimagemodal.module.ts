import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChatimagemodalPage } from './chatimagemodal';

@NgModule({
  declarations: [
    ChatimagemodalPage,
  ],
  imports: [
    IonicPageModule.forChild(ChatimagemodalPage),
  ],
})
export class ChatimagemodalPageModule {}
